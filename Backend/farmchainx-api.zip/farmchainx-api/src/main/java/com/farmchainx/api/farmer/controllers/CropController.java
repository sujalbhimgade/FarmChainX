package com.farmchainx.api.farmer.controllers;

import com.farmchainx.api.farmer.dto.CropDto;
import com.farmchainx.api.farmer.dto.CropResponse;
import com.farmchainx.api.farmer.entities.Crop;
import com.farmchainx.api.farmer.services.CropService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crops")
public class CropController {
  private final CropService service;
  public CropController(CropService service) {
    this.service = service;
  }

  @PostMapping
  public ResponseEntity<Crop> create(@RequestBody @Valid CropDto dto) {
    return ResponseEntity.ok(service.create(dto));
  }

  @GetMapping
  public ResponseEntity<List<Crop>> myCrops() {
    return ResponseEntity.ok(service.myCrops());
  }

  @GetMapping("/{id}")
  public ResponseEntity<Crop> byId(@PathVariable Long id) {
    return ResponseEntity.ok(service.one(id));
  }

  @PatchMapping("/{id}")
  @PreAuthorize("@cropService.canEdit(#id)")
  public ResponseEntity<CropResponse> update(@PathVariable Long id, @RequestBody CropDto dto) {
    return ResponseEntity.ok(service.toResponse(service.updatePartial(id, dto)));
  }

  @DeleteMapping("/{id}")
  @PreAuthorize("@cropService.canEdit(#id)")
  public ResponseEntity<Void> delete(@PathVariable Long id) {
    service.deleteById(id);
    return ResponseEntity.noContent().build();
  }
}
