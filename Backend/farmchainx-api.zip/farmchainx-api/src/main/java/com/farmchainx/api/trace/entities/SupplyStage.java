package com.farmchainx.api.trace.entities;

public enum SupplyStage {
  FARMER, DISTRIBUTOR, RETAILER, CONSUMER
}
