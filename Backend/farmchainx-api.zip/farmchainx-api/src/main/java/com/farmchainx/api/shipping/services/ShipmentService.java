package com.farmchainx.api.shipping.services;

import com.farmchainx.api.auth.entities.User;
import com.farmchainx.api.auth.repo.UserRepository;
import com.farmchainx.api.farmer.entities.Crop;
import com.farmchainx.api.farmer.repo.CropRepository;
import com.farmchainx.api.security.SecurityUtils;
import com.farmchainx.api.shipping.dto.*;
import com.farmchainx.api.shipping.entities.*;
import com.farmchainx.api.shipping.repo.ShipmentRepository;
import com.farmchainx.api.trace.entities.SupplyStage;
import com.farmchainx.api.trace.services.TraceService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Random;

@Service("shipmentService")
public class ShipmentService {
  private final ShipmentRepository shipments;
  private final CropRepository crops;
  private final UserRepository users;
  private final TraceService trace;

  public ShipmentService(ShipmentRepository shipments, CropRepository crops, UserRepository users, TraceService trace) {
    this.shipments = shipments;
    this.crops = crops;
    this.users = users;
    this.trace = trace;
  }

  @Transactional(readOnly = true)
  public boolean canUpdate(Long id) {
    var me = SecurityUtils.currentUser(users).orElse(null);
    var s = shipments.findById(id).orElse(null);
    if (me == null || s == null) return false;
    return me.getId().equals(s.getFromUser().getId()) || me.getId().equals(s.getToUser().getId());
  }

  @Transactional
  public ShipmentResponse create(ShipmentCreateRequest req) {
    User farmer = SecurityUtils.currentUser(users).orElseThrow();
    Crop crop = crops.findById(req.cropId()).orElseThrow();
    User distributor = users.findById(req.distributorUserId()).orElseThrow();

    String batch = crop.getBatchCode();
    if (batch == null || batch.isBlank()) {
      batch = "BATCH-" + System.currentTimeMillis() + "-" + new Random().nextInt(1000);
      crop.setBatchCode(batch);
      crops.save(crop);
    }

    String tracking = "TRK-" + System.currentTimeMillis() + "-" + new Random().nextInt(1000);

    double total = req.quantityKg() * req.unitPrice();

    Shipment s = Shipment.builder()
        .trackingCode(tracking)
        .batchCode(batch)
        .crop(crop)
        .fromUser(farmer)
        .toUser(distributor)
        .fromStage(SupplyStage.FARMER)
        .toStage(SupplyStage.DISTRIBUTOR)
        .originLocation(crop.getFieldLocation())
        .destinationLocation(req.destinationLocation())
        .quantityKg(req.quantityKg())
        .unitPrice(req.unitPrice())
        .totalValue(total)
        .vehicle(req.vehicle())
        .status(ShipmentStatus.CREATED)
        .createdAt(Instant.now())
        .updatedAt(Instant.now())
        .expectedDelivery(req.expectedDelivery())
        .build();

    Shipment saved = shipments.save(s);
    trace.add(saved.getBatchCode(), SupplyStage.FARMER, saved.getOriginLocation(), "Shipment created " + saved.getTrackingCode(), farmer);
    return toResponse(saved);
  }

  @Transactional(readOnly = true)
  public List<ShipmentResponse> myOutgoing() {
    User me = SecurityUtils.currentUser(users).orElseThrow();
    return shipments.findByFromUser(me).stream().map(this::toResponse).toList();
  }

  @Transactional(readOnly = true)
  public List<ShipmentResponse> myIncoming() {
    User me = SecurityUtils.currentUser(users).orElseThrow();
    return shipments.findByToUser(me).stream().map(this::toResponse).toList();
  }

  @Transactional
  public ShipmentResponse updateStatus(Long id, ShipmentUpdateRequest req) {
    User me = SecurityUtils.currentUser(users).orElseThrow();
    Shipment s = shipments.findById(id).orElseThrow();

    if (!canUpdate(id)) throw new IllegalStateException("Not allowed");

    s.setStatus(req.status());
    if (req.temperatureC() != null) s.setTemperatureC(req.temperatureC());
    if (req.humidity() != null) s.setHumidity(req.humidity());
    s.setUpdatedAt(Instant.now());

    String where = req.currentLocation() != null ? req.currentLocation() : (s.getDestinationLocation() != null ? s.getDestinationLocation() : "N/A");
    trace.add(s.getBatchCode(),
        s.getToStage(), // journey step toward the receiver
        where,
        "Shipment " + s.getTrackingCode() + " → " + req.status(),
        me);

    return toResponse(shipments.save(s));
  }

  private ShipmentResponse toResponse(Shipment s) {
    return new ShipmentResponse(
        s.getId(),
        s.getTrackingCode(),
        s.getBatchCode(),
        s.getCrop().getId(),
        s.getCrop().getName(),
        s.getCrop().getType(),
        s.getFromUser().getId(),
        s.getFromUser().getFullName(),
        s.getToUser().getId(),
        s.getToUser().getFullName(),
        s.getQuantityKg(),
        s.getUnitPrice(),
        s.getTotalValue(),
        s.getOriginLocation(),
        s.getDestinationLocation(),
        s.getVehicle(),
        s.getTemperatureC(),
        s.getHumidity(),
        s.getStatus(),
        s.getFromStage(),
        s.getToStage(),
        s.getCreatedAt(),
        s.getUpdatedAt(),
        s.getExpectedDelivery()
    );
  }
}
