package com.farmchainx.api.trace.repo;

import com.farmchainx.api.trace.entities.TraceEvent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TraceEventRepository extends JpaRepository<TraceEvent, Long> {
  List<TraceEvent> findByBatchCodeOrderByCreatedAtAsc(String batchCode);
}
