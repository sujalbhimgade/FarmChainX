package com.farmchainx.api.shipping.entities;

public enum ShipmentStatus {
  CREATED, ACCEPTED, IN_TRANSIT, DELIVERED, CANCELLED
}
