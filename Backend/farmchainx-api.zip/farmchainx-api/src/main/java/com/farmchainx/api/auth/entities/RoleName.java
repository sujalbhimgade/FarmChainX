package com.farmchainx.api.auth.entities;

public enum RoleName { FARMER, DISTRIBUTOR, RETAILER, CONSUMER, ADMIN }
