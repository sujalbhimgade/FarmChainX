package com.farmchainx.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmchainxApiApplication {
  public static void main(String[] args) {
    SpringApplication.run(FarmchainxApiApplication.class, args);
    
  }
}
